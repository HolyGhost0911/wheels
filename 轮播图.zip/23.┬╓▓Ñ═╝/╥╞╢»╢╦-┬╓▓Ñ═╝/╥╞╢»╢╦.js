window.addEventListener('load', function () {

    var focus = this.document.querySelector('.focus');
    var ul = focus.children[0];
    var ol = focus.children[1]
    var w = focus.offsetWidth; //获取focus的宽度
    var index = 0;
    var timer = setInterval(function () {
        index++;
        var boxMove = -index * w
        ul.style.transform = 'translateX(' + boxMove + 'px)';
        ul.style.transition = 'all .5s'
    }, 2500);

    //等过渡完成之后 再判断 监听过渡完成的事件  transitionend
    ul.addEventListener('transitionend', function () {
        if (index >= 5) {
            index = 0;
            //console.log(index);
            ul.style.transition = 'none'; //去掉过渡效果
            var boxMove = -index * w //利用最新的索引号 继续滚动
            ul.style.transform = 'translateX(' + boxMove + 'px)';
        } else if (index < 0) {
            index = 2
            ul.style.transition = 'none'; //去掉过渡效果
            var boxMove = -index * w //利用最新的索引号 继续滚动
            ul.style.transform = 'translateX(' + boxMove + 'px)';
        }

        //小圆点跟随变化
        //  将ol里面的li带有current类名的选出来去除掉  remove
        ol.querySelector('.current').classList.remove('current');
        //  让当前索引号 的小li 加上current类名
        ol.children[index].classList.add('current');

    })


    //手指滑动轮播图
    //触摸元素  获取手指的初始目标
    var startX = 0;
    var moveX = 0;

    var flag = false; //
    ul.addEventListener('touchstart', function (e) {
        startX = e.targetTouches[0].pageX;
        clearInterval(timer); //手指触摸时  停止定时器
    })
    //移动手指   计算手指的滑动距离 , 并且移动盒子
    ul.addEventListener('touchmove', function (e) {
        //计算移动距离
        moveX = e.targetTouches[0].pageX - startX;
        //移动盒子 : 盒子原来的位置 + 手指移动的距离
        var boxMove = -index * w + moveX;

        ul.style.transition = 'none'; //手指移动无需过渡动画  取消过渡动画效果
        ul.style.transform = 'translateX(' + boxMove + 'px)';

        flag = true; //若手指有移动  再做判断  手指不移动 则不进行判断
        e.preventDefault(); //阻止 滚动屏幕的行为
    })

    //手指离开  根据移动距离去判断是否回弹 或 是否播放下一张(上一张)
    ul.addEventListener('touchend', function () {
        if (flag == true) {
            //若滑动距离大于50 则播放下一张(上一张)
            if (Math.abs(moveX) > 50) { //Math.abs()取绝对值
                //若右滑 则拨放上一张 即(moveX 是正值)
                if (moveX > 0) {
                    index--;
                } else { //若左滑 则播放下一张 即(moveX 是负值)
                    index++;
                }
                var boxMove = -index * w;
                ul.style.transform = 'translateX(' + boxMove + 'px)';
                ul.style.transition = 'all .5s'
            } else { //如果移动距离小于50px  则回弹
                var boxMove = -index * w;
                ul.style.transform = 'translateX(' + boxMove + 'px)';
                ul.style.transition = 'all .3s'
            }
        }


        clearInterval(timer); //先清除 定时器
        //手指离开  重新开启定时器
        timer = setInterval(function () {
            index++;
            var boxMove = -index * w
            ul.style.transform = 'translateX(' + boxMove + 'px)';
            ul.style.transition = 'all .5s'
        }, 2500);
    })
})