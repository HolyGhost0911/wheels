window.addEventListener('load', function () {

    //动画(横向缓动动画)
    //target目标位置
    //interval间隔事件
    //callback回调函数(可不填)
    function animate(obj, target, interval, callback) {
        //清除定时器
        clearInterval(obj.timer)
        obj.timer = setInterval(function () {
            //步长
            var step = (target - obj.offsetLeft) / 10
            step = step > 0 ? Math.ceil(step) : Math.floor(step)
            //到目标位置停止
            if (obj.offsetLeft == target) {
                clearInterval(obj.timer)
                callback && callback();
            }
            obj.style.left = obj.offsetLeft + step + "px"
        }, interval)
    }


    var focus = document.querySelector('.focus'); //获取轮播图最外层

    var focusWidth = focus.offsetWidth; //获取 图片宽度
    var leftButton = document.querySelector('.button-left'); //获取左箭头
    var rightButton = document.querySelector('.button-right'); //获取右箭头

    //箭头按钮的显示隐藏
    focus.addEventListener('mouseenter', function () {
        leftButton.style.display = 'block';
        rightButton.style.display = 'block';

        clearInterval(timer);
        timer = null; //鼠标经过 就 清空定时器

    })
    focus.addEventListener('mouseleave', function () {
        leftButton.style.display = 'none';
        rightButton.style.display = 'none';

        //轮播图自动播放   鼠标离开 开启定时器
        timer = setInterval(function () {
            rightButton.click(); //手动调用 向右按钮的点击事件
        }, 2000);
    })


    //动态生成小圆点 ,  小圆点onclick事件
    var ul = focus.querySelector('ul'); //获取储存所有图片的大盒子

    var ol = focus.querySelector('.circle'); //获取储存小圆点的容器

    //var li = ol.querySelectorAll('li');
    for (var i = 0; i < ul.children.length; i++) { //遍历大盒子中的图片
        //创建小圆点 li
        var li = document.createElement('li');
        li.setAttribute('index', i); //给每个li添加一个index属性 值为i
        //把创建的小圆点插入 ol中

        ol.appendChild(li)
        //小圆点onclick事件(排他思想),提前创建类名为current的小圆点background-color

        li.addEventListener('click', function () {
            for (var i = 0; i < ol.children.length; i++) {
                ol.children[i].style.backgroundColor = '';
                ol.children[i].style.opacity = ' .5'
            }
            this.style.backgroundColor = '#f0932b';
            this.style.opacity = ' 1'
            //点击小圆点 滚动到对应图片(即 移动ul)
            //ul 的距离 就是 (小圆点的索引号*图片的宽度)
            var index = this.getAttribute('index'); //把li 的索引号获取 再赋值给index
            num = index; //当点击某个小圆点  就让这个小圆点的索引号 赋值给 num
            circle = index; //当点击某个小圆点  就让这个小圆点的索引号 赋值给 小圆点circle
            animate(ul, -index * focusWidth, 30)
        })
    }

    //左右箭头按钮 onclick事件

    var first = ul.children[0].cloneNode(true); //克隆第一张图片
    ul.appendChild(first); //添加到父级元素的最后一个
    var num = 0;

    var circle = 0; //小圆点跟随图片

    var flag = true; //节流阀  防止按钮连续点击导致的图片播放过快
    rightButton.addEventListener('click', function () {
        if (flag) {
            flag = false; //关闭节流阀

            //无缝滚动  首先 复制第一张图片到最后一张 滑到最后一张图的时候 ul快速复原(即 left 改为0)
            if (num == ul.children.length - 1) {
                ul.style.left = 0;
                num = 0;
            }
            num++;
            animate(ul, -num * focusWidth, 30, function () {
                flag = true; //节流阀的回调函数
            })

            circle++;
            //若circle == ol.children.length 说明走到最后的克隆图片  就父元小圆点 即 circle == 0
            if (circle == ol.children.length) {
                circle = 0;
            }
            for (var i = 0; i < ol.children.length; i++) {
                ol.children[i].style.backgroundColor = '';
                ol.children[i].style.opacity = ' .5'
            }
            ol.children[circle].style.backgroundColor = '#f0932b';
            ol.children[circle].style.opacity = ' 1'

        }
    })
    leftButton.addEventListener('click', function () {

        if (flag) {
            flag = false;

            //无缝滚动  首先 复制第一张图片到最后一张 滑到最后一张图的时候 ul快速复原(即 left 改为0)
            if (num == 0) {
                num = ul.children.length - 1;
                ul.style.left = -num * focusWidth + 'px';
            }
            num--; //由于是反向
            animate(ul, -num * focusWidth, 30, function () {
                flag = true; //节流阀的回调函数
            })

            circle--;
            //若circle < 0   就父元小圆点 即 circle == ol.children.length-1
            if (circle < 0) {
                circle = ol.children.length - 1;
            }
            for (var i = 0; i < ol.children.length; i++) {
                ol.children[i].style.backgroundColor = '';
                ol.children[i].style.opacity = ' .5'
            }
            ol.children[circle].style.backgroundColor = '#f0932b';
            ol.children[circle].style.opacity = ' 1'

        }
    })

    //轮播图自动播放
    var timer = setInterval(function () {
        rightButton.click(); //手动调用 向右按钮的点击事件
    }, 3000);
})